#include "Config.h"

#include <cstring>
#include <streambuf>
#include <string>
#include <vector>

#if defined(_DFF_ON_WINDOWS_)
# include <direct.h>
# include <shellapi.h>
# include "Shlwapi.h"
#else
# include <unistd.h>
# include <stdlib.h>
#endif

#include "Exception.h"
#include "ExceptionUtils.h"
#include "FilesystemUtils.h"
#include "Log.h"
#include "StringUtils.h"
#include "SystemUtils.h"


#define TEMP_DIR_ENV_VARIABLE_NAME "DINAMICA_TEMP_DIR"


namespace DFF {


namespace {


std::string getUserTemporaryDirectory() {
  return DFF::SystemUtils::getEnvironmentVariableValue( 
      TEMP_DIR_ENV_VARIABLE_NAME );
}

std::string getOSTemporaryDirectory() {
#ifdef _DFF_ON_WINDOWS_
  size_t numTries = 0;
  std::vector< wchar_t > tmpBuffer( 1024, 0 );

  do {
    DWORD numChars = ::GetTempPathW( tmpBuffer.size() - 1, tmpBuffer.data() );
    if ( numChars == 0 ) {
      throwException( DFF::Exception, 
        "Failed to get system temporary directory." );
    }

    if ( numChars < tmpBuffer.size() ) {
      break;
    } else {
      tmpBuffer.reserve( tmpBuffer.capacity() + 256 );
      memset( tmpBuffer.data(), 0, tmpBuffer.size() * sizeof( wchar_t ) );
    }
  } while ( numTries++ < 10 );

  tmpBuffer[ tmpBuffer.size() - 1 ] = 0;
  return StringUtils::toUTF8( std::wstring( tmpBuffer.data() ) );

#else

  std::string tmpBuffer = 
    DFF::SystemUtils::getEnvironmentVariableValue( "TMPDIR" );

  if ( tmpBuffer.empty() )
    tmpBuffer = "/tmp";

  return tmpBuffer;
#endif
}

std::string getSystemTemporaryDirectory() {
  const auto userDirectory( getUserTemporaryDirectory() );
  const auto tmpDirectory( getOSTemporaryDirectory() );
  return userDirectory.empty() ? tmpDirectory : userDirectory;
}


} // namespace ''


std::string FilesystemUtils::getCompleteTemporaryPath( const std::string& baseName ) {
#ifdef _DFF_ON_WINDOWS_
  return ( getSystemTemporaryDirectory() + "\\" + baseName );
#else
  return ( getSystemTemporaryDirectory() + "/" + baseName );
#endif
}

std::string FilesystemUtils::getTemporaryFilename( const std::string& extension ) {
#ifdef _DFF_ON_WINDOWS_
  const std::wstring systemTempDir( 
    StringUtils::fromUTF8( getSystemTemporaryDirectory() ) );

  wchar_t tempFilenameBuffer[ 1024 ] = { 0 };
  if ( ::GetTempFileNameW( systemTempDir.c_str(),
    L"EGO", 0, tempFilenameBuffer ) == 0 ) {

    std::string errMsg;
    SystemUtils::getLastSystemError( errMsg );

    throwException( DFF::Exception, "Failed to get temporary file: " <<
      errMsg );
  }

  return StringUtils::toUTF8( std::wstring( tempFilenameBuffer ) ) + extension;
#else
  std::string tempFilename( getSystemTemporaryDirectory() + 
    "/dinamica-ego-r-XXXXXX" );

  char* tempFilenameBuffer = strdup( tempFilename.c_str() );
  const int fileDescriptor = mkstemp( tempFilenameBuffer );
  if ( fileDescriptor != -1 ) {
    std::string resultString( tempFilenameBuffer );
    free( tempFilenameBuffer );
    close( fileDescriptor );

    return resultString + extension;
  } else {
    std::string errMsg;
    SystemUtils::getLastSystemError( errMsg );

    throwException( DFF::Exception, "Failed to get temporary file: " <<
      errMsg );
  }

  // Nunca deve alcançar.
  return std::string();
#endif
}
  
void FilesystemUtils::deleteFile( const FILE_STRING& filename ) {
#ifdef _DFF_ON_WINDOWS_
  if ( DeleteFileW( filename.c_str() ) == 0 )
    logInfo( "Failed to remove file \"" << FROM_FS( filename ) << "\"." );
#else
  if ( ::remove( FROM_FS( filename ).c_str() ) != 0 )
    logInfo( "Failed to remove file \"" << FROM_FS( filename ) << "\"." );
#endif
}

FileHandle::FileHandle( const FILE_STRING& filename, const FILE_STRING& mode ) 
  : m_handle( 0 ),
    m_isOpen( false ),
    m_filename( filename ) {

#ifdef _DFF_ON_WINDOWS_
  m_handle = ::_wfopen( filename.c_str(), mode.c_str() );
#else
  m_handle = ::fopen( filename.c_str(), mode.c_str() );
#endif

  m_isOpen = ( m_handle != 0 );
}

FileHandle::~FileHandle() {
  close( true );
}
  
long FileHandle::tellg() const {
  BOOST_ASSERT( m_isOpen );
  BOOST_ASSERT( m_handle != 0 );
  return ftell( m_handle );
}

void FileHandle::seek( long pos ) {
  BOOST_ASSERT( m_isOpen );
  BOOST_ASSERT( m_handle != 0 );
  fseek( m_handle, pos, SEEK_SET );
}

void FileHandle::read( char* result, size_t numBytes ) {
  BOOST_ASSERT( m_isOpen );
  BOOST_ASSERT( m_handle != 0 );
  fread( result, numBytes, 1, m_handle );
}

void FileHandle::write( const char* data, size_t numBytes ) {
  BOOST_ASSERT( m_isOpen );
  BOOST_ASSERT( m_handle != 0 );
  fwrite( data, numBytes, 1, m_handle );
}

void FileHandle::close( bool noExcept ) {
  if ( m_isOpen ) {
    if ( fclose( m_handle ) != 0 && !noExcept ) {
      throwException( DFF::Exception, "Failed to close filename \"" << 
        FROM_FS( m_filename ) << "\"" );
    }

    m_filename = FILE_STRING();
    m_isOpen = false;
    m_handle = 0;
  }
}

void FileHandle::flush() {
  fflush( m_handle );
}


} // namespace DFF

