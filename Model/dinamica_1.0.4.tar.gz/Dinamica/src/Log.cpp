/**
   \file Log.cpp

   Copyright&copy; 1998-2018 Centro de Sensoriamento Remoto / Universidade
   Federal de Minas Gerais - Brazil.
   All Rights Reserved.

   \author Romulo Fernandes Machado
*/


#include "Log.h"
#include "StringUtils.h"


namespace DFF {


void Logger::log( const std::string& message) {
  std::string rString = StringUtils::toR( message );
  Rprintf( "%s\n", rString.c_str() );
}


} // namespace DFF

