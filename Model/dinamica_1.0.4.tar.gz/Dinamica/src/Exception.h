#ifndef _DFF_EXCEPTION_H_
#define _DFF_EXCEPTION_H_


#include "Config.h"

#include <exception>
#include <string>
#include <vector>

namespace DFF {


enum ExceptionConstant {
  EC_NAME_LENGTH        = 128,
  EC_DESCRIPTION_LENGTH = 1024
};

class DFF_PUBLIC Exception : public std::exception {
public:
  Exception( const std::string& description = "" );

protected:
  Exception( const std::string& name, const std::string& description );

public:
  Exception( const Exception& exception );
  ~Exception()
    throw () {
  }

  const char *what()
    const throw() override {
    return ( m_description[ 0 ] == '\0' )? 
      m_name : m_description;
  }

  const char *getName() const {
    return m_name;
  }

  const char *getDescription() const {
    return m_description;
  }

  Exception& operator=( const Exception& exception );

private:
  char m_name[ EC_NAME_LENGTH ];
  char m_description[ EC_DESCRIPTION_LENGTH ];
}; /* Exception */


} /* DFF */


#endif /* _DFF_EXCEPTION_H_ */

