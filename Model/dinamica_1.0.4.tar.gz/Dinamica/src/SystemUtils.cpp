#include "Config.h"

#define _DFF_CPP_LIBRARY_ BaseLib

#include <string>
#if defined(_DFF_ON_WINDOWS_)
# include <windows.h>
# include <Shlobj.h>
#elif defined(_DFF_ON_LINUX_)
# include <cstring>
# include <linux/unistd.h>
#elif defined(_DFF_ON_MAC_)
# include <cstring>
#endif

#include <cstdlib>
#include <sstream>

#include "Exception.h"
#include "ExceptionUtils.h"
#include "Log.h"
#include "StringUtils.h"
#include "SystemUtils.h"


namespace {


template < typename T >
std::string toString( T param ) {
  std::stringstream __str;
  __str << param;

  return __str.str();
}


}


namespace DFF {


bool SystemUtils::getLastSystemError( std::string& message ) {
#if defined(_DFF_ON_WINDOWS_)

  DWORD errorCode = GetLastError();
  LPVOID messageBuffer = 0;

  if ( errorCode != 0 ) {
    logDebug2( "System error detected. Retrieving last error message:" );

    if ( ::FormatMessage( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM |
      FORMAT_MESSAGE_IGNORE_INSERTS, NULL, errorCode,
      MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPTSTR) & messageBuffer,
      0, NULL ) != 0 ) {
      message = std::string( (LPCTSTR) messageBuffer );

      LocalFree( messageBuffer );

    } else
      message = "Error #" + toString( errorCode );

    logDebug2( "Last error message retrieved successfully: " << message );

    return true;

  } else
    return false;

#else

  int errorCode = errno;
  if ( errorCode != 0 ) {
    logDebug2( "System error detected. Retrieving last error message:" );

    std::stringstream errorMsg;
    errorMsg << "Error #" << errorCode << ", " << ::strerror( errorCode );
    logDebug2( "Last error message retrieved successfully: " << errorMsg.str() );

    return true;

  } else
    return false;

#endif
}

std::string SystemUtils::getEnvironmentVariableValue( const std::string& tmpVariableName ) {
#ifdef _DFF_ON_WINDOWS_
  const std::wstring variableName( StringUtils::fromUTF8( tmpVariableName ) );
  std::wstring returnValue;
  std::size_t pathLen = 0;

  if ( ::_wgetenv_s( &pathLen, NULL, 0, variableName.c_str() ) == 0 
    && pathLen != 0 ) {

    // Aloca o espaço necessário e lê a variável.
    wchar_t* pathValue = new wchar_t[ pathLen ];
    memset( pathValue, 0, pathLen * sizeof( wchar_t ) );

    if ( ::_wgetenv_s( &pathLen, pathValue, pathLen, variableName.c_str() ) == 0 
      && pathLen != 0 ) {

      returnValue = std::wstring( pathValue );
    }

    // Apaga o espaço alocado.
    delete [] pathValue;
  }

  return StringUtils::toUTF8( returnValue );

#else // _DFF_ON_WINDOWS_

  const char* variableValue = std::getenv( tmpVariableName.c_str() );
  if ( variableValue != nullptr )
    return std::string( variableValue );
  else
    return std::string();
#endif // _DFF_ON_WINDOWS_
}


} /* DFF */

