#include "Config.h"

#include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include "Exception.h"
#include "StringUtils.h"
#include <Rcpp.h>


namespace DFF {


Exception::Exception( const std::string& description ) {
  const std::string rDescription( DFF::StringUtils::toR( description ) );
  memset( m_name, 0, EC_NAME_LENGTH );
  memset( m_description, 0, EC_DESCRIPTION_LENGTH );

  static const char* _exceptionName = "Exception";
  std::strncpy( m_name, _exceptionName, 
    std::min( (size_t) EC_NAME_LENGTH, (size_t) strlen( _exceptionName ) ) );
  std::strncpy( m_description, rDescription.c_str(), 
    std::min( (size_t) EC_DESCRIPTION_LENGTH, rDescription.length() ) );
}
  
Exception::Exception( const std::string& name, const std::string& description ) {
  const std::string rDescription( DFF::StringUtils::toR( description ) );
  memset( m_name, 0, EC_NAME_LENGTH );
  memset( m_description, 0, EC_DESCRIPTION_LENGTH );

  std::strncpy( m_name, name.c_str(), 
    std::min( (size_t) EC_NAME_LENGTH, name.length() ) );
  std::strncpy( m_description, rDescription.c_str(), 
    std::min( (size_t) EC_DESCRIPTION_LENGTH, rDescription.length() ) );
}

Exception::Exception( const Exception& exception ) {
  std::strncpy( m_name, exception.m_name, EC_NAME_LENGTH );
  std::strncpy( m_description, exception.m_description, EC_DESCRIPTION_LENGTH );
}

Exception& Exception::operator=( const Exception& exception ) {
  if ( this != &exception ) {
    std::strncpy( m_name, exception.m_name, EC_NAME_LENGTH );
    std::strncpy( m_description, exception.m_description, EC_DESCRIPTION_LENGTH );
  }
  
  return *this;
}


} // namespace DFF

