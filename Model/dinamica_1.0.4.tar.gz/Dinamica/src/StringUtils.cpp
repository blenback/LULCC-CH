#include "Config.h"

#include <string>
#if defined(_DFF_ON_WINDOWS_)
# include <windows.h>
# include <Stringapiset.h>
# include <Shlobj.h>
#elif defined(_DFF_ON_LINUX_)
# include <cstring>
# include <codecvt>
# include <linux/unistd.h>
#endif

#include <cstdlib>
#include <sstream>

#include "Exception.h"
#include "ExceptionUtils.h"
#include "Log.h"
#include "StringUtils.h"


namespace DFF {


std::string StringUtils::toUTF8( const std::wstring& input ) {
#ifdef _DFF_ON_WINDOWS_
  int outputLength = ::WideCharToMultiByte(
    CP_UTF8,
    0,
    input.c_str(),
    static_cast< int >( input.length() ),
    NULL,
    0,
    NULL,
    NULL );

  std::string output;

  if ( outputLength != 0 ) {
    output.resize( outputLength );

    ::WideCharToMultiByte(
      CP_UTF8,
      0,
      input.c_str(),
      static_cast< int >( input.length() ),
      const_cast< char * >(output.c_str()),
      outputLength,
      NULL,
      NULL);
  }

  return output;
#else
  std::wstring_convert< std::codecvt_utf8< wchar_t > > myConv;
  return myConv.to_bytes( input );
#endif
}

std::wstring StringUtils::fromUTF8( const std::string& input ) {
#ifdef _DFF_ON_WINDOWS_
  const int nChars = ::MultiByteToWideChar( CP_UTF8, 0,
    input.data(), input.length(), 0, 0 );

  if ( nChars == 0 )
    return std::wstring();

  std::wstring newbuffer;
  newbuffer.resize( nChars );
  ::MultiByteToWideChar( CP_UTF8, 0, input.data(),
    input.length(), const_cast< wchar_t* >( newbuffer.c_str() ), nChars );

  return newbuffer;
#else
  return std::wstring( input.begin(), input.end() );
#endif
}
  
std::string StringUtils::toR( const std::string& inputString ) {
  std::string resultString;

  void* resourcePtr = Riconv_open( "", "UTF-8" );
  if ( resourcePtr != nullptr ) {
    std::vector< char > inBuffer, outBuffer;
    for ( char ch : inputString ) 
      inBuffer.push_back( ch );

    inBuffer.push_back( 0 );
    outBuffer.resize( inputString.length() * 2 + 1, 0 );

    const char* inputStr = inBuffer.data();
    char* outputStr = outBuffer.data();

    size_t inSize = inputString.length();
    size_t outSize = outBuffer.size();

    size_t resultSize = Riconv( resourcePtr, &inputStr, &inSize, 
      &outputStr, &outSize );

    int64_t outputStringStartOffset = outBuffer.size() - outSize;
    size_t outputStringSize = static_cast< size_t >( 
      std::max( ( int64_t ) 0, outputStringStartOffset ) );

    Riconv_close( resourcePtr );

    if ( outputStringSize > 0 
      && inSize == 0 
      && resultSize != static_cast< size_t >( -1 ) ) {

      resultString = std::string( outBuffer.data(), outputStringSize );
    }
  }
    
  if ( resultString.empty() )
    resultString = inputString;

  return resultString;
}


} /* DFF */

