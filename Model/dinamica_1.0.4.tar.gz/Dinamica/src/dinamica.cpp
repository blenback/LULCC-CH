#include <Rcpp.h>

#include <chrono>
#include <cstdio>
#include <mutex>
#include <sstream>
#include <thread>

#include "Exception.h"
#include "ExceptionUtils.h"
#include "ExternalCommunication.h"
#include "FilesystemUtils.h"
#include "StringUtils.h"


namespace {


/**
   \brief Escreve a tabela passada pelo R em um arquivo CSV.

   Implementação da escrita (essa implementação pode disparar livremente
   uma vez que os erros serão capturados um nível acima).
*/
void writeTableToFileImpl( const Rcpp::DataFrame& table, 
  DFF::FileHandle& writeFile, int64_t keyColumnsMaxIndex ) {

  const Rcpp::CharacterVector names( table.attr( "names" ) );
  const auto namesCount = names.size();

  // Armazena as colunas da tabela.
  std::vector< Rcpp::List > tableColumns;

  for ( auto i = 0; i < namesCount; ++i ) {
    if ( i > 0 )
      writeFile.write( ", ", 2 );

    const std::string columnName( names[ i ] );
    writeFile.write( columnName.c_str(), columnName.length() );

    if ( i < keyColumnsMaxIndex && columnName.rfind( "*" ) == std::string::npos ) {
      writeFile.write( "*", 1 );
    }

    tableColumns.push_back( table[ columnName.c_str() ] );
  }

  writeFile.write( "\n", 1 );

  // Recupera o número de entradas da tabela através
  // do tamanho da primeira coluna.
  BOOST_ASSERT( tableColumns.empty() == false );
  const auto rowsCount = tableColumns[ 0 ].size();

  // Escreve as linhas
  for ( auto rowIndex = 0; rowIndex < rowsCount; ++rowIndex ) {
    for ( auto colIndex = 0; colIndex < namesCount; ++colIndex ) {
      const Rcpp::List& column = tableColumns[ colIndex ];
      if ( colIndex > 0 )
        writeFile.write( ", ", 2 );

      const auto columnData( column[ rowIndex ] );
      if ( Rcpp::is< std::string >( columnData ) ) {
        const std::string writeData( Rcpp::as< std::string >( columnData ) );
        writeFile.write( "\"", 1 );
        writeFile.write( writeData.c_str(), writeData.length() );
        writeFile.write( "\"", 1 );
      } else if ( Rcpp::is< double >( columnData ) ) {
        const std::string writeData( DFF::StringUtils::toString( 
          Rcpp::as< double >( columnData ) ) );

        writeFile.write( writeData.c_str(), writeData.length() );
      } else if ( Rcpp::is< int >( columnData ) ) {
        const std::string writeData( DFF::StringUtils::toString( 
          Rcpp::as< int >( columnData ) ) );

        writeFile.write( writeData.c_str(), writeData.length() );
      } else if ( Rcpp::is< bool >( columnData ) ) {
        const std::string writeData( DFF::StringUtils::toString( 
          Rcpp::as< bool >( columnData ) ) );

        writeFile.write( writeData.c_str(), writeData.length() );
        writeFile.write( "\"", 1 );
        writeFile.write( writeData.c_str(), writeData.length() );
        writeFile.write( "\"", 1 );
      } else {
        throwException( DFF::Exception, "Only numeric types and string convertible "
          "types are acceptable." );
      }
    }
      
    writeFile.write( "\n", 1 );
  }
}

/**
   \brief Escreve a tabela passada pelo R em um arquivo CSV.
   Dispara se não for possível escrever a tabela.
*/
void writeTableToFile( const Rcpp::DataFrame& table, 
  const std::string& filename, int64_t keyColumnsMaxIndex ) {

#ifdef _DFF_ON_WINDOWS_
  DFF::FileHandle writeFile( TO_FS( filename ), L"w" );
#else
  DFF::FileHandle writeFile( TO_FS( filename ), "w" );
#endif

  if ( !writeFile.is_open() ) {
    throwException( DFF::Exception, "Failed to open \"" << filename << 
      "\" for writing." );
  }
  
  try {
    // Configura a precisão correta.
    writeTableToFileImpl( table, writeFile, keyColumnsMaxIndex );

  } catch ( ... ) {

    // Remove o arquivo uma vez que ele não será mais enviado e já foi aberto.
    writeFile.close();
    DFF::FilesystemUtils::deleteFile( TO_FS( filename ) );
    throw;
  }
}


} // namespace ''


// General implementation for cancellable (NOT thread safe).
DFF::Cancellable* getCancellable() {
  static DFF::Cancellable lastCancellable;
  return &lastCancellable;
}

// Gerencia a singleton da sessão
DFF::ExternalCommunication& Instance() {
  static DFF::ExternalCommunication* instance = 
    new DFF::ExternalCommunication();

  return *instance;
}

//[[Rcpp::export]]
RcppExport SEXP openSession( SEXP identifier ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();
  communicationInstance.openSession( Rcpp::as< std::string >( identifier ) );

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP createSession( SEXP identifier ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();
  communicationInstance.createSession( Rcpp::as< std::string >( identifier ) );

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP destroySession( SEXP identifier ) {
BEGIN_RCPP
  DFF::ExternalCommunication::destroySession( Rcpp::as< std::string >( identifier ) );

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendNumber( SEXP number ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();
  communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
    ( int ) DFF::ExternalMessageTypes::EMT_NUMBER, 
    Rcpp::as< double >( number ) ), "", getCancellable() );

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendNamedNumber( SEXP name, SEXP number ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();
  communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
    ( int ) DFF::ExternalMessageTypes::EMT_NUMBER, 
    Rcpp::as< double >( number ) ), Rcpp::as< std::string >( name ), getCancellable() );

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP receiveNumber() {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();

  auto message = communicationInstance.receiveMessage( "", getCancellable() );
  if ( message.m_identifier != DFF::EMT_NUMBER )
    throwException( DFF::Exception, "Received message does not contain a number." );

  return Rcpp::wrap( message.m_number );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP receiveNamedNumber( SEXP name ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();

  auto message = communicationInstance.receiveMessage( Rcpp::as< std::string >( name ), getCancellable() );
  if ( message.m_identifier != DFF::EMT_NUMBER )
    throwException( DFF::Exception, "Received message does not contain a number." );

  return Rcpp::wrap( message.m_number );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendNumberVector( SEXP numberVector ) {
BEGIN_RCPP
  Rcpp::NumericVector list( numberVector );
  auto getNumber = [ & ]( size_t index ) -> double {
    return list[ index ];
  };

  const std::string tmpFilename( DFF::FilesystemUtils::getTemporaryFilename() );

  try {
    DFF::ExternalCommunication::storeNumbersOnFilename( list.size(), 
      getNumber, tmpFilename );

    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
      ( int ) DFF::ExternalMessageTypes::EMT_NUMBER_LIST, 
      tmpFilename ), "", getCancellable() );

  } catch ( ... ) {

    DFF::FilesystemUtils::deleteFile( TO_FS( tmpFilename ) );
    throw;
  }

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendNamedNumberVector( SEXP name, SEXP numberVector ) {
BEGIN_RCPP
  Rcpp::NumericVector list( numberVector );
  auto getNumber = [ & ]( size_t index ) -> double {
    return list[ index ];
  };

  const std::string tmpFilename( DFF::FilesystemUtils::getTemporaryFilename() );

  try {
    DFF::ExternalCommunication::storeNumbersOnFilename( list.size(), 
      getNumber, tmpFilename );

    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
      ( int ) DFF::ExternalMessageTypes::EMT_NUMBER_LIST, 
      tmpFilename ), Rcpp::as< std::string >( name ), getCancellable() );

  } catch ( ... ) {

    DFF::FilesystemUtils::deleteFile( TO_FS( tmpFilename ) );
    throw;
  }

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP receiveNumberVector() {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();

  auto message = communicationInstance.receiveMessage( "", getCancellable() );
  if ( message.m_identifier != DFF::EMT_NUMBER_LIST )
    throwException( DFF::Exception, "Received message does not contain a number list." );

  std::vector< double > numbers;
  auto setNumber = [ & ]( double number ) {
    numbers.push_back( number );
  };

  DFF::ExternalCommunication::getNumbersFromFilename( setNumber, message.getString() );
  DFF::FilesystemUtils::deleteFile( TO_FS( message.getString() ) );

  return Rcpp::wrap( numbers );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP receiveNamedNumberVector( SEXP name ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();

  auto message = communicationInstance.receiveMessage( Rcpp::as< std::string >( name ), getCancellable() );
  if ( message.m_identifier != DFF::EMT_NUMBER_LIST )
    throwException( DFF::Exception, "Received message does not contain a number list." );

  std::vector< double > numbers;
  auto setNumber = [ & ]( double number ) {
    numbers.push_back( number );
  };

  DFF::ExternalCommunication::getNumbersFromFilename( setNumber, message.getString() );
  DFF::FilesystemUtils::deleteFile( TO_FS( message.getString() ) );

  return Rcpp::wrap( numbers );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendLookupTable( SEXP keysVector, SEXP valuesVector ) {
BEGIN_RCPP
  Rcpp::NumericVector keys( keysVector );
  Rcpp::NumericVector values( valuesVector );

  if ( keys.size() != values.size() )
    throwException( DFF::Exception, "Keys and values vector must have the same size." );

  const size_t numbersCount = keys.size() + values.size();
  auto getNumber = [ & ]( size_t index ) -> double {
    if ( index < ( size_t ) keys.size() )
      return keys[ index ];
    else
      return values[ index - keys.size() ];
  };

  const std::string tmpFilename( DFF::FilesystemUtils::getTemporaryFilename() );

  try {
    DFF::ExternalCommunication::storeNumbersOnFilename( numbersCount, 
      getNumber, tmpFilename );

    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
      ( int ) DFF::ExternalMessageTypes::EMT_LOOKUP_TABLE, 
      tmpFilename ), "", getCancellable() );

  } catch ( ... ) {

    DFF::FilesystemUtils::deleteFile( TO_FS( tmpFilename ) );
    throw;
  }

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendNamedLookupTable( SEXP name, SEXP keysVector, SEXP valuesVector ) {
BEGIN_RCPP
  Rcpp::NumericVector keys( keysVector );
  Rcpp::NumericVector values( valuesVector );

  if ( keys.size() != values.size() )
    throwException( DFF::Exception, "Keys and values vector must have the same size." );

  const size_t numbersCount = keys.size() + values.size();
  auto getNumber = [ & ]( size_t index ) -> double {
    if ( index < ( size_t ) keys.size() )
      return keys[ index ];
    else
      return values[ index - keys.size() ];
  };

  const std::string tmpFilename( DFF::FilesystemUtils::getTemporaryFilename() );

  try {
    DFF::ExternalCommunication::storeNumbersOnFilename( numbersCount, 
      getNumber, tmpFilename );

    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
      ( int ) DFF::ExternalMessageTypes::EMT_LOOKUP_TABLE, 
      tmpFilename ), Rcpp::as< std::string >( name ), getCancellable() );

  } catch ( ... ) {

    DFF::FilesystemUtils::deleteFile( TO_FS( tmpFilename ) );
    throw;
  }

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport Rcpp::DataFrame receiveLookupTable() {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();

  auto message = communicationInstance.receiveMessage( "", getCancellable() );
  if ( message.m_identifier != DFF::EMT_LOOKUP_TABLE )
    throwException( DFF::Exception, "Received message does not contain a lookup table." );

  std::vector< double > numbers;
  auto setNumber = [ & ]( double number ) {
    numbers.push_back( number );
  };

  DFF::ExternalCommunication::getNumbersFromFilename( setNumber, message.getString() );
  DFF::FilesystemUtils::deleteFile( TO_FS( message.getString() ) );

  Rcpp::NumericVector keys; 
  Rcpp::NumericVector values;

  size_t numberOfKeys = numbers.size() / 2;
  for ( size_t i = 0; i < numberOfKeys; ++i ) {
    const double key = numbers[ i ];
    const double value = numbers[ i + numberOfKeys ];

    keys.push_back( key );
    values.push_back( value );
  }

  return Rcpp::DataFrame::create( Rcpp::Named( "Keys" ) = keys,
                                  Rcpp::Named( "Values" ) = values );
END_RCPP
}

//[[Rcpp::export]]
RcppExport Rcpp::DataFrame receiveNamedLookupTable( SEXP name ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();

  auto message = communicationInstance.receiveMessage( Rcpp::as< std::string >( name ), getCancellable() );
  if ( message.m_identifier != DFF::EMT_LOOKUP_TABLE )
    throwException( DFF::Exception, "Received message does not contain a lookup table." );

  std::vector< double > numbers;
  auto setNumber = [ & ]( double number ) {
    numbers.push_back( number );
  };

  DFF::ExternalCommunication::getNumbersFromFilename( setNumber, message.getString() );
  DFF::FilesystemUtils::deleteFile( TO_FS( message.getString() ) );

  Rcpp::NumericVector keys; 
  Rcpp::NumericVector values;

  size_t numberOfKeys = numbers.size() / 2;
  for ( size_t i = 0; i < numberOfKeys; ++i ) {
    const double key = numbers[ i ];
    const double value = numbers[ i + numberOfKeys ];

    keys.push_back( key );
    values.push_back( value );
  }

  return Rcpp::DataFrame::create( Rcpp::Named( "Keys" ) = keys,
                                  Rcpp::Named( "Values" ) = values );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendString( SEXP str ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();
  communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
    ( int ) DFF::ExternalMessageTypes::EMT_STRING, 
    Rcpp::as< std::string >( str ) ), "", getCancellable() );

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendNamedString( SEXP name, SEXP str ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();
  communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
    ( int ) DFF::ExternalMessageTypes::EMT_STRING, 
    Rcpp::as< std::string >( str ) ), Rcpp::as< std::string >( name ), getCancellable() );

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP receiveString() {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();

  auto message = communicationInstance.receiveMessage( "", getCancellable() );
  if ( message.m_identifier != DFF::EMT_STRING )
    throwException( DFF::Exception, "Received message does not contain a string." );

  return Rcpp::wrap( DFF::StringUtils::toR( message.getString() ) );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP receiveNamedString( SEXP name ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();

  auto message = communicationInstance.receiveMessage( Rcpp::as< std::string >( name ), getCancellable() );
  if ( message.m_identifier != DFF::EMT_STRING )
    throwException( DFF::Exception, "Received message does not contain a string." );

  return Rcpp::wrap( DFF::StringUtils::toR( message.getString() ) );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendErrorString( SEXP str ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();
  communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
    ( int ) DFF::ExternalMessageTypes::EMT_ERROR_DESCRIPTION, 
    Rcpp::as< std::string >( str ) ), "", getCancellable() );

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendTable( SEXP argTable, int64_t numberOfKeyColumns = -1 ) {
BEGIN_RCPP
  const std::string tmpFilename( DFF::FilesystemUtils::getTemporaryFilename( ".csv" ) );
  const Rcpp::DataFrame table( argTable );
  writeTableToFile( table, tmpFilename, numberOfKeyColumns );

  try {
    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
      ( int ) DFF::ExternalMessageTypes::EMT_TABLE, 
      tmpFilename ), "", getCancellable() );

  } catch ( ... ) {
    DFF::FilesystemUtils::deleteFile( TO_FS( tmpFilename ) );
    throw;
  }

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport SEXP sendNamedTable( SEXP name, SEXP argTable, int64_t numberOfKeyColumns = -1 ) {
BEGIN_RCPP
  const std::string tmpFilename( DFF::FilesystemUtils::getTemporaryFilename( ".csv" ) );
  const Rcpp::DataFrame table( argTable );
  writeTableToFile( table, tmpFilename, numberOfKeyColumns );

  try {
    DFF::ExternalCommunication& communicationInstance = Instance();
    communicationInstance.sendMessage( DFF::ExternalCommunication::Message( 
      ( int ) DFF::ExternalMessageTypes::EMT_TABLE, 
      tmpFilename ), Rcpp::as< std::string >( name ), getCancellable() );

  } catch ( ... ) {
    DFF::FilesystemUtils::deleteFile( TO_FS( tmpFilename ) );
    throw;
  }

  return Rcpp::wrap( 0 );
END_RCPP
}

//[[Rcpp::export]]
RcppExport Rcpp::DataFrame receiveTable() {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();

  auto message = communicationInstance.receiveMessage( "", getCancellable() );
  if ( message.m_identifier != DFF::EMT_TABLE )
    throwException( DFF::Exception, "Received message does not contain a table." );

  // Transform filename to UTF8 string.
  std::string filename = DFF::StringUtils::toR( message.getString() );

  Rcpp::Language readCSV( "read.csv", filename, Rcpp::Named( "header", true ),
    Rcpp::Named( "sep", ',' ), Rcpp::Named( "dec", '.' ), Rcpp::Named( "fill", true ),
    Rcpp::Named( "stringsAsFactors", false ), Rcpp::Named( "strip.white", true ) );

  try {
    const SEXP resultTable = readCSV.eval();
    DFF::FilesystemUtils::deleteFile( TO_FS( message.getString() ) );

    return resultTable;
  } catch ( ... ) {
    DFF::FilesystemUtils::deleteFile( TO_FS( message.getString() ) );
    throw;
  } 
END_RCPP
}

//[[Rcpp::export]]
RcppExport Rcpp::DataFrame receiveNamedTable( SEXP name ) {
BEGIN_RCPP
  DFF::ExternalCommunication& communicationInstance = Instance();

  auto message = communicationInstance.receiveMessage( Rcpp::as< std::string >( name ), getCancellable() );
  if ( message.m_identifier != DFF::EMT_TABLE )
    throwException( DFF::Exception, "Received message does not contain a table." );
  
  // Transform filename to UTF8 string.
  std::string filename = DFF::StringUtils::toR( message.getString() );

  Rcpp::Language readCSV( "read.csv", filename, Rcpp::Named( "header", true ),
    Rcpp::Named( "sep", ',' ), Rcpp::Named( "dec", '.' ), Rcpp::Named( "fill", true ),
    Rcpp::Named( "stringsAsFactors", false ), Rcpp::Named( "strip.white", true ) );

  try {
    const SEXP resultTable = readCSV.eval();
    DFF::FilesystemUtils::deleteFile( TO_FS( message.getString() ) );

    return resultTable;
  } catch ( ... ) {
    DFF::FilesystemUtils::deleteFile( TO_FS( message.getString() ) );
    throw;
  } 
END_RCPP
}

