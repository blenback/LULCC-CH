#ifndef _DFF_CANCELLABLE_H_
#define _DFF_CANCELLABLE_H_

#include "Config.h"

// [[Rcpp::depends(RcppProgress)]]
#include <interrupts.hpp>


namespace DFF {


class DFF_PUBLIC Cancellable {
public:
  bool isCancelled() const {
    return checkInterrupt();
  }
}; /* Cancellable */


} /* DFF */


#endif /* _DFF_CANCELLABLE_H_ */
