/**
   \file FilesystemLock.h

   \brief Defini��o de uma trava para acesso exclusivo � arquivos.

   Copyright&copy; 1998-2016 Centro de Sensoriamento Remoto / Universidade
   Federal de Minas Gerais - Brazil.
   All Rights Reserved.

   \author Romulo Fernandes Machado
*/


#ifndef _DFF_FILENAME_LOCK_H_
#define _DFF_FILENAME_LOCK_H_


#include "Config.h"

#include <string>

#ifdef _DINAMICA_EGO_
# undef _DFF_H_LIBRARY_
# define _DFF_H_LIBRARY_ BaseLib
# include "Library.h"
#endif

#ifdef _DFF_ON_WINDOWS_
# define _WINDOWS_
#endif


namespace DFF {


/**
   \brief Trava para acesso exclusivo � um arquivo.

   A trava � obtida no construtor e liberada no destrutor.
   Esse arquivo n�o poder� ser utilizado para leitura e escrita,
   ele apenas serve como uma trava no sistema de arquivos (como um mutex).
*/
class DFF_PUBLIC FilenameLock {
public:

  /**
     \brief Comportamento esperado ao tentar pegar a trava do arquivo e falhar.
  */
  enum LockBehavior {

    /**
       \brief Uma espera ocupada ser� feita caso o n�o seja poss�vel travar
       o arquivo (esse � o modo padr�o).
    */
    LB_WAIT_ON_BUSY,

    /**
       \brief Uma exce��o ser� disparada no construtor caso n�o seja poss�vel
       travar o arquivo.
    */
    LB_THROW_ON_BUSY
  };

  /**
     \brief Obt�m uma trava para o nome de arquivo passado.

     \param filename Nome de arquivo a ter o acesso exclusivo.

     \param lockBehavior Comportamento esperado ao tentar realizar a trava. @see LockBehavior

     \exception Exception Caso n�o seja poss�vel obter uma trava para o arquivo.
  */
  FilenameLock( const FILE_STRING& filename, LockBehavior lockBehavior = LB_WAIT_ON_BUSY );

  /**
     \brief Libera a trava para o nome de arquivo especificado no construtor.
  */
  ~FilenameLock();

  /**
     \brief Libera a trava para o nome de arquivo especificado no construtor.
  */
  void release() noexcept;

private:

  /**
     \brief Trava para o arquivo usada pelo sistema.
  */
#ifdef _WINDOWS_
  HANDLE m_handle;
#else
  // Armazena o file descriptor do arquivo.
  int m_handle;
#endif


}; /* FilenameLock */


} /* DFF */

  
#endif /* _DFF_FILENAME_LOCK_H_ */
