/**
   \file ExternalCommunication.h

   \brief Utilit�rio para comunica��o com aplica��es externas.

   Copyright&copy; 1998-2017 Centro de Sensoriamento Remoto / Universidade
   Federal de Minas Gerais - Brazil.
   All Rights Reserved.

   \author Romulo Fernandes Machado
*/


#ifndef _DINAMICA_EXTERNA_COMMUNICATION_H_
#define _DINAMICA_EXTERNA_COMMUNICATION_H_

#include "Config.h"

#include <array>
#include <functional>
#include <memory>
#include <string>
#include <vector>
#include <thread>

#include "Cancellable.h"
#include "FileMessageQueue.h"
#include "FileTaggedMessageQueue.h"

// Evita que bibliotecas externas incluam arquivos do Dinamica.
#ifdef _DINAMICA_EGO_
#  include "SingletonHolder.h"
#  undef _DFF_H_LIBRARY_
#  define _DFF_H_LIBRARY_ BaseLib
#  include "Library.h"
#endif

#define SHARED_QUEUE_SERVER_SUFFIX "_serverQueue"
#define SHARED_QUEUE_CLIENT_SUFFIX "_clientQueue"
#define QUEUE_MAX_MESSAGES 1024
#define MAX_FILENAME_PATH_SIZE 1024


namespace DFF {


/**
   \brief Tipos b�sicos de mensagem trocadas em conex�es externas.
*/
enum ExternalMessageTypes {

  /**
     \brief Um �nico n�mero � enviado no pr�prio corpo da mensagem.
  */
  EMT_NUMBER = 0,

  /**
     \brief Uma lista de n�meros � passada como conte�do de um arquivo.
  */
  EMT_NUMBER_LIST,

  /**
     \brief Uma tabela (n�meros) � passada como conte�do de um arquivo.
  */
  EMT_LOOKUP_TABLE,

  /**
     \brief Uma string � passada no campo da mensagem.
  */
  EMT_STRING,

  /**
     \brief Uma mensagem de erro � passada no campo da mensagem.
  */
  EMT_ERROR_DESCRIPTION,

  /**
     \brief Uma tabela � passada como conte�do de um arquivo (CSV).
  */
  EMT_TABLE,

  /**
     \brief Mensagens customizadas devem ser passadas com identificador
     maior que esse n�mero.
  */
  EMT_MAX_MESSAGE_TYPES
};

/**
   \brief Gerencia comunica��o com aplica��es externas.
   modelos.
*/
class DFF_PUBLIC ExternalCommunication {
public:

  /**
     \brief Mensagem trocada entre processos.

     No caso da integra��o com o R (ou outras ferramentas), os arquivos
     que definem as mensagens nos outros projetos devem ter o mesmo formato
     de mensagem do Dinamica.
  */
  struct Message {

    /**
       \brief Indentificador do conte�do / prop�sito da mensagem.
    */
    uint32_t m_identifier;

    /**
       \brief Espa�o para que seja gravado um n�mero.
    */
    double m_number;

    /**
       \brief Espa�o para que seja gravado uma string.
       O tamanho m�ximo dessa string deve ser MAX_FILENAME_PATH_SIZE.
    */
    std::array< char, MAX_FILENAME_PATH_SIZE > m_string;

    /**
       \brief Constr�i uma mensagem vazia.
    */
    Message() 
      : m_identifier( 0 ), 
        m_number( 0 ) {
    
      m_string.fill( 0 );
    }

    /**
       \brief Constr�i uma mensagem apenas com identificador.
    */
    explicit Message( uint32_t identifier ) 
      : m_identifier( identifier ),
        m_number( 0 ) {

      m_string.fill( 0 );
    }

    /**
       \brief Constr�i uma mensagem com identificador e um n�mero.
    */
    explicit Message( uint32_t identifier, double number )
      : m_identifier( identifier ),
        m_number( number ) {

      m_string.fill( 0 );
    }

    /**
       \brief Constr�i uma mensagem com identificador e um nome de arquivo.
    */
    explicit Message( uint32_t identifier, 
      const std::array< char, MAX_FILENAME_PATH_SIZE >& string )
      : m_identifier( identifier ),
        m_number( 0 ),
        m_string( string ) {
    }

    /**
       \brief Constr�i uma mensagem com identificador e um nome de arquivo.
    */
    explicit Message( uint32_t identifier, const std::string& string )
      : m_identifier( identifier ),
        m_number( 0 ) { 

      m_string.fill( 0 );
      for ( size_t i = 0; i < string.length(); ++i )
        m_string[ i ] = string[ i ];
    }

    /**
       \brief Retorna a string armazenada na mensagem como std::string.
    */
    std::string getString() const { 
      return std::string( m_string.data() );
    }
  };

  /**
     \brief Constr�i uma inst�ncia de comunica��o com aplica��es externas.

     Essa sess�o n�o troca dados at� que seja inicializada ou conectada � 
     uma outra sess�o j� existente.
   */
  ExternalCommunication();

  /**
     \brief Finaliza a sess�o interrompendo quaisquer conex�es existentes.
   */
  ~ExternalCommunication();

  /**
     \brief Inicializa a sess�o para compartilhamento de informa��es com aplica��es
     externas.
     (DISPON�VEL NO JAVA).
   
     \param sessionIdentifier Identificador da sess�o a ser criada.
   
     \exception DFF::Exception Caso a sess�o n�o possa ser criada.
   */
  void createSession( const std::string& sessionIdentifier );

  /**
     \brief Encerra a sess�o de compartilhamento.
     (DISPON�VEL NO JAVA).
   */
  void destroy();

  /**
     \brief Conecta a uma sess�o ativa para compartilhamento de informa��es com
     aplica��es externas.

     \param sessionIdentifier Identificador �nico de sess�o, esse identificador 
     deve respeitar as normas de nome do C++ (impostas pelo boost).
   
     \exception DFF::Exception Caso a sess�o n�o possa ser conectada.
   */
  void openSession( const std::string& sessionIdentifier );

  /**
     \brief Envia uma mensagem atrav�s da fila de mensagens.

     \param message Mensagem a ser enviada.
     
     \param cancellable Ponteiro para cancellable para verifica��o de 
     interrup��es (opcional).

     Caso a fila esteja cheia, bloqueia at� que a mensagem possa ser
     enviada.
  */
  void sendMessage( const Message& message, const std::string& tag = std::string(), 
    Cancellable* cancellable = nullptr );

  /**
     \brief Recebe a primeira mensagem da fila.

     \param cancellable Ponteiro para cancellable para verifica��o de 
     interrup��es (opcional).

     A mensagem recebida ser� removida da fila e n�o poder� ser recuperada
     novamente. Caso a fila esteja vazia, bloqueia at� que uma mensagem seja
     recebida.
  */
  Message receiveMessage( const std::string& tag = std::string(), 
    Cancellable* cancellable = nullptr );

  /**
     \brief Utilit�rio para remover uma sess�o existente pelo nome.

     \param identifier Identificador da sess�o a ser destru�da.
  */
  static void destroySession( const std::string& identifier );

  /**
     \brief Retorna se uma sess�o j� existe.
     (DISPON�VEL NO JAVA).

     \param identifier Identificador da sess�o a ser descoberta.
  */
  static bool sessionExists( const std::string& identifier );

  /**
     \brief Retorna o identificador usado.
     (DISPON�VEL NO JAVA).
  */
  inline const std::string& getIdentifier() const {
    return m_sessionIdentifier;
  }

  /**
     \brief Retorna o n�mero m�ximo de mensagens que podem
     ser enviadas antes da fila ser travada.
  */
  size_t getMaxNumberOfMessages() const;

  /**
     \brief Grava uma lista de n�meros no arquivo passado.

     \param numberCount Quantidade de n�meros que devem ser lidos.

     \param getNumber Fun��o respons�vel por retornar cada n�mero a partir 
     do �ndice pedido.

     \param filename Caminho v�lido para o arquivo onde os n�meros ser�o 
     gravados.
  */
  static void storeNumbersOnFilename( size_t numberCount,
    const std::function< double( size_t ) >& getNumber,
    const std::string& filename );

  /**
     \brief Recupera uma lista de n�meros do arquivo passado.

     \param setNumber Fun��o respons�vel por receber cada n�mero da lista lida.

     \param filename Caminho v�lido para o arquivo onde os n�meros est�o gravados.
  */
  static void getNumbersFromFilename( const std::function< void( double ) >& setNumber,
    const std::string& filename );

private:

  /**
     \brief Indica se a sess�o aberta foi constru�da ou apenas conectada
     � uma sess�o j� existente.
  */
  bool m_sessionCreated;

  /**
     \brief Identificador �nico da sess�o. Esse identificador deve ter as 
     mesmas restri��es que nomes de vari�veis em C++ (impostas pelo boost).
  */
  std::string m_sessionIdentifier;

  /**
     \brief Fila de mensagens para envio.
  */
  std::shared_ptr< FileMessageQueue > m_sendQueue;

  /**
     \brief Fila de mensagens (com tag) para envio.
  */
  std::shared_ptr< FileTaggedMessageQueue > m_tagSendQueue;

  /**
     \brief Fila de mensagens para recebimento.
  */
  std::shared_ptr< FileMessageQueue > m_receiveQueue;

  /**
     \brief Fila de mensagens (com tag) para recebimento.
  */
  std::shared_ptr< FileTaggedMessageQueue > m_tagReceiveQueue;

}; /* ExternalCommunication */


// Evita que bibliotecas externas incluam arquivos do Dinamica.
#ifdef _DINAMICA_EGO_


/**
   Gerenciador comunica��o com aplica��es externas.

   \attention � definido usando heran�a, e n�o \c typedef, para que possa
   ser usado fora dos limites dessa biblioteca.
*/
class DFF_PUBLIC ExternalCommunicationManager : public SingletonHolder< ExternalCommunication > {
public:
  // A reimplementa��o de Instance() � necess�ria para que v�rias
  // factories n�o sejam criadas nas bordas das DLLs.
  static ExternalCommunication& Instance();
}; /* ExternalCommunicationManager */


#endif // _DINAMICA_EGO_

/**
   \brief Grava a representa��o do tipo de mensagem no stream dado.
*/
DFF_PUBLIC std::ostream& operator<<( std::ostream& os, ExternalMessageTypes type );


} /* DFF */


#endif /* _DINAMICA_EXTERNA_COMMUNICATION_H_ */
