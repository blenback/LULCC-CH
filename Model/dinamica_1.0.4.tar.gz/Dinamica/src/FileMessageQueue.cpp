/**
   \file FileMessageQueue.cpp

   \brief Fila de mensagens utilizando um arquivo para leitura e escrita.

   Copyright&copy; 1998-2016 Centro de Sensoriamento Remoto / Universidade
   Federal de Minas Gerais - Brazil.
   All Rights Reserved.

   \author Romulo Fernandes Machado
*/


#include "Config.h"
#define _DFF_CPP_LIBRARY_ BaseLib

#include <chrono>
#include <cstdio>
#include <cstring>
#include <thread>

#include "Exception.h"
#include "ExceptionUtils.h"

#include "FileMessageQueue.h"
#include "FilesystemUtils.h"
#include "FilenameLock.h"
#include "Log.h"
#include "StringUtils.h"

#ifdef _DFF_ON_WINDOWS_
# define _WINDOWS_
#endif

#define BLOCK_SLEEP_INTERVAL_MS 100

#ifdef _DFF_ON_WINDOWS_
# define LOCK_SUFFIX L".lock"
#else
# define LOCK_SUFFIX ".lock"
#endif


namespace DFF {


namespace {


void writeHeader( FileHandle& handle, 
  const DFF::FileMessageQueue::Header& header ) {

  handle.seek( 0 );
  handle.write( ( char* ) &header, sizeof( DFF::FileMessageQueue::Header ) );
  handle.flush();
}

template < typename T >
DFF::FileMessageQueue::Header getHeader( T& handle ) {
  DFF::FileMessageQueue::Header header;

  handle.seek( 0 );
  handle.read( ( char* ) &header, sizeof( DFF::FileMessageQueue::Header ) );

  return header;
}


} // namespace ''


FileMessageQueue::FileMessageQueue( const FILE_STRING& filename, 
  size_t messageSize, size_t messageCount ) 
  : m_filename( filename ),
    m_messageSize( messageSize ),
    m_maximumMessageCount( messageCount ) { 

  // Obt�m a trava exclusiva para cria��o do arquivo (como sup�e-se que 
  // o arquivo n�o existe, dispara se a trava existir).
  const FILE_STRING lockFilename( m_filename + LOCK_SUFFIX );
  const FilenameLock lock( lockFilename, FilenameLock::LB_THROW_ON_BUSY );

  // Verifica se a sess�o j� existe.
  if ( FileHandle( m_filename, TO_FS( "r" ) ).is_open() )
    throwException( DFF::Exception, "Failed to create message "
      "queue \"" << FROM_FS( m_filename ) << "\". Session already exist." );

  // Cria o arquivo em modo bin�rio.
  FileHandle handle( m_filename, TO_FS( "wb" ) );
  if ( handle.is_open() == false )
    throwException( DFF::Exception, "Failed to create message "
      "queue \"" << FROM_FS( m_filename ) << "\"." );

  // Escreve o cabe�alho com as informa��es 
  const FileMessageQueue::Header header = { 0, 0, messageSize, messageCount };
  handle.write( ( char* ) &header, sizeof( FileMessageQueue::Header ) );
  handle.flush();

  // Escreve no arquivo bytes suficientes para acomodar todas as mensagens.
  char* data = new char[ messageSize * messageCount ];
  memset( data, 0, messageSize * messageCount );

  handle.write( data, messageSize * messageCount );
  handle.flush();

  delete [] data;
}

FileMessageQueue::FileMessageQueue( const FILE_STRING& filename ) 
  : m_filename( filename ) {

  // Obt�m a trava exclusiva para leitura do arquivo.
  const FILE_STRING lockFilename( m_filename + LOCK_SUFFIX );
  const FilenameLock lock( lockFilename );

  FileHandle handle( m_filename, TO_FS( "r+b" ) );
  if ( handle.is_open() == false )
    throwException( DFF::Exception, "Failed to open message "
      "queue \"" << FROM_FS( m_filename ) << "\"." );

  // Recupera o cabe�alho para preencher o tamanho da mensagem armazenada.
  const FileMessageQueue::Header header( getHeader( handle ) );
  m_messageSize = header.blockSize;
  m_maximumMessageCount = header.blockCount;
}


void FileMessageQueue::write( const void* data, size_t size, 
  Cancellable* cancellable ) {

  while ( true ) {
    const FILE_STRING lockFilename( m_filename + LOCK_SUFFIX );
    FilenameLock lock( lockFilename );

    FileHandle handle( m_filename, TO_FS( "r+b" ) );
    if ( handle.is_open() == false )
      throwException( DFF::Exception, "Failed to open message "
        "queue \"" << FROM_FS( m_filename ) << "\"." );

    FileMessageQueue::Header header( getHeader( handle ) );

    // Enquanto o ponteiro de escrita n�o alcan�ar o ponteiro de leitura,
    // a escrita pode ser feita.
    const size_t nextWritePtr = ( header.writePtr + 1 ) % header.blockCount;
    if ( nextWritePtr != header.readPtr ) {
      size_t offset = sizeof( FileMessageQueue::Header ) + 
        header.writePtr * header.blockSize;

      handle.seek( offset );
      handle.write( ( const char* ) data, size );
      handle.flush();

      header.writePtr = nextWritePtr;
      writeHeader( handle, header );

      break;
    }

    // Libera o lock e espera um timeout para uma nova tentativa.
    lock.release();
    std::this_thread::sleep_for( std::chrono::milliseconds( BLOCK_SLEEP_INTERVAL_MS ) );

    if ( cancellable != nullptr && cancellable->isCancelled() )
      throwException( DFF::Exception, "Execution aborted." );

  } // while ( true )
}


void FileMessageQueue::read( void* data, size_t size, Cancellable* cancellable ) {
  while ( true ) {
    const FILE_STRING lockFilename( m_filename + LOCK_SUFFIX );
    FilenameLock lock( lockFilename );

    FileHandle handle( m_filename, TO_FS( "r+b" ) );
    if ( handle.is_open() == false )
      throwException( DFF::Exception, "Failed to open message "
        "queue \"" << FROM_FS( m_filename ) << "\"." );

    FileMessageQueue::Header header( getHeader( handle ) );

    // Uma leitura pode ser feita desde que os dois ponteiros n�o estejam
    // na mesma posi��o.
    if ( header.readPtr != header.writePtr ) {
      size_t offset = sizeof( FileMessageQueue::Header ) + 
        header.readPtr * header.blockSize;

      handle.seek( offset );
      handle.read( ( char* ) data, size );

      header.readPtr = ( header.readPtr + 1 ) % header.blockCount;
      writeHeader( handle, header );

      break;
    }

    // Libera o lock e espera um timeout para uma nova tentativa.
    lock.release();
    std::this_thread::sleep_for( std::chrono::milliseconds( BLOCK_SLEEP_INTERVAL_MS ) );

    if ( cancellable != nullptr && cancellable->isCancelled() )
      throwException( DFF::Exception, "Execution aborted." );

  } // while ( true )
}

void FileMessageQueue::destroy( const FILE_STRING& filename ) {

  logDebug( "Destroying file message queue \"" << FROM_FS( filename + LOCK_SUFFIX ) << "\"" );
  FilesystemUtils::deleteFile( filename + LOCK_SUFFIX );

  logDebug( "Destroying file message queue \"" << FROM_FS( filename ) << "\"" );
  FilesystemUtils::deleteFile( filename );
}


} // namespace DFF
