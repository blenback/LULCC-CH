#ifndef _DFF_STRING_UTILS_H_
#define _DFF_STRING_UTILS_H_


#include "Config.h"

#include <limits>
#include <sstream>
#include <string>

#ifdef _DFF_ON_WINDOWS_
# include <windows.h>
#endif


namespace DFF {


class DFF_PUBLIC StringUtils {
public:
  static std::string toUTF8( const std::wstring& input );

  static std::wstring fromUTF8( const std::string& input );

  static std::string toR( const std::string& input );

  template < typename T >
  static std::string toString( T value ) {
    std::stringstream _str;
    _str.precision( std::numeric_limits< double >::digits10 );
    _str << value;

    return _str.str();
  }
    
};


} /* DFF */


#endif
