#ifndef _DFF_LOG_H_
#define _DFF_LOG_H_


#include "Config.h"

// R Dependencies
#include <Rcpp.h>
#include <R_ext/Riconv.h>

#include <iomanip>
#include <iostream>
#include <list>
#include <string>
#include <sstream>
#include <vector>

namespace DFF {


class Logger {
public:
  static void log( const std::string& message);
};


#define logInfo( MESSAGE )                                                     \
  do {                                                                         \
    std::stringstream __str;                                                   \
    __str << MESSAGE << std::endl;                                             \
    Logger::log( __str.str() );                                                \
  } while( false )

#define logDebug( MESSAGE ) logInfo( MESSAGE )
#define logDebug2( MESSAGE ) logInfo( MESSAGE )


} /* DFF */


#endif /* _DFF_LOG_H_ */
