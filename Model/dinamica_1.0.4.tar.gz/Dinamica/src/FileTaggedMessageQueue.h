/**
   \file FileTaggedMessageQueue.h

   \brief Fila de mensagens (com tag) utilizando um arquivo para leitura 
   e escrita.

   Copyright&copy; 1998-2017 Centro de Sensoriamento Remoto / Universidade
   Federal de Minas Gerais - Brazil.
   All Rights Reserved.

   \author Romulo Fernandes Machado
*/


#ifndef _DFF_FILE_TAGGED_MESSAGE_QUEUE_H_
#define _DFF_FILE_TAGGED_MESSAGE_QUEUE_H_


#include "Config.h"
#include "Cancellable.h"

#include <string>

#ifdef _DINAMICA_EGO_
# undef _DFF_H_LIBRARY_
# define _DFF_H_LIBRARY_ BaseLib
# include "Library.h"
#endif

#ifdef _DFF_ON_WINDOWS_
# define _WINDOWS_
#endif


#define MAX_MESSAGE_TAG_LENGTH 512


namespace DFF {


/**
   \brief Escreve e l� mensagens em um arquivo. 
   
   Essas mensagens s�o transferidas usando uma string como Tag, e s�o lidas 
   apenas atrav�s das tags. Se uma tag � escrita mais de uma vez, a mensagem 
   anterior relativa a tag � sobrescrita.

   As opera��es de leitura e escrita dessa classe s�o O(n).
*/

class DFF_PUBLIC FileTaggedMessageQueue {
public:

  /**
     \brief Cabe�alho do arquivo contendo as mensagens.
  */
  struct Header {

    /**
       \brief Tamanho do bloco de mensagem.
    */
    uint64_t blockSize;

    /**
       \brief Quantidade de blocos alocados.
    */
    uint64_t blockCount;
  };

  /**
     \brief Cabe�alho de cada mensagem armazenada no arquivo.
  */
  struct MessageHeader {
    
    /**
       \brief Armazena se o slot utilizado pela mensagem est� em uso.
    */
    bool inUse;

    /**
       \brief Tag usada para identificar a mensagem.
    */
    char tag[ MAX_MESSAGE_TAG_LENGTH ];

    MessageHeader() = default;
    MessageHeader( bool inUse, const std::string& passedTag ) 
      : inUse( inUse ) {

      setTag( passedTag );
    }

    /**
       \brief Copia a tag passada para a estrutura interna da tag.
    */
    void setTag( const std::string& passedTag ) {
      const size_t minSize = std::min( size_t( MAX_MESSAGE_TAG_LENGTH - 1 ), 
        passedTag.length() );

      memcpy( tag, passedTag.c_str(), minSize );
      tag[ MAX_MESSAGE_TAG_LENGTH - 1 ] = 0;
    }

    /**
       \brief Compara a tag passada com a tag armazenada na mensagem.
     */
    bool hasTag( const std::string& passedTag ) const {
      const size_t minCompareSize = std::min( size_t( MAX_MESSAGE_TAG_LENGTH ), 
        passedTag.length() );

      for ( size_t i = 0; i < minCompareSize; ++i )
        if ( tag[ i ] != passedTag[ i ] )
          return false;

      return true;
    }
  };

  /**
     \brief Cria um novo arquivo contendo uma fila de mensagens.

     \param filename Nome do arquivo contendo as mensagens.

     \param messageSize Tamanho em bytes das mensagens a serem gravadas.

     \param messageCount N�mero m�ximo de mensagens a serem gravadas no arquivo.
  */
  FileTaggedMessageQueue( const FILE_STRING& filename, size_t messageSize, 
    size_t messageCount );

  /**
     \brief Abre um arquivo contendo uma fila de mensagens.

     \param filename Nome do arquivo contendo as mensagens.
  */
  FileTaggedMessageQueue( const FILE_STRING& filename );

  /**
     \brief Escreve uma mensagem na fila. Bloqueia se a fila estiver cheia.


     \param tag String contendo a tag usada para grava��o da mensagem. Caso
     a tag j� exista no arquivo, ela ser� substitu�da.

     \param data Ponteiro para o buffer de dados a ser escrito.

     \param size N�mero de bytes a serem escritos.

     \param cancellable Ponteiro para cancellable para verifica��o de 
     interrup��es (opcional).
  */
  void write( const std::string& tag, const void* data, size_t size, 
    Cancellable* cancellable = nullptr );

  /**
     \brief L� uma mensagem da fila. Bloqueia se a fila estiver vazia.

     \param data Ponteiro para o buffer de dados onde as informa��es lidas 
     ser�o gravadas.

     \param size N�mero de bytes a serem lidos.

     \param cancellable Ponteiro para cancellable para verifica��o de 
     interrup��es (opcional).
  */
  void read( const std::string& tag, void* data, size_t size, 
    Cancellable* cancellable = nullptr );

  /**
     \brief Destr�i os arquivos utilizados por uma fila.

     \param filename Nome de arquivo utilizado para cria��o da fila.
  */
  static void destroy( const FILE_STRING& filename );

  /**
     \brief Retorna o n�mero m�ximo de mensagens que podem ser gravadas 
     no arquivo.
  */
  inline const size_t getMaximumMessageCount() const {
    return m_maximumMessageCount;
  }

private:

  /**
     \brief Nome do arquivo onde a fila de mensagem est� salva.
  */
  FILE_STRING m_filename;

  /**
     \brief Tamanho (em bytes) de cada mensagem armazenada na fila.
  */
  size_t m_messageSize;

  /**
     \brief Armazena o n�mero m�ximo de mensagens que podem ser armazenadas.
  */
  size_t m_maximumMessageCount;

}; /* FileTaggedMessageQueue */


} /* DFF */


#endif /* _DFF_FILE_MESSAGE_QUEUE_H_ */
