/**
   \file FilenameLock.cpp

   \brief Defini��o de uma trava para acesso exclusivo � arquivos.

   Copyright&copy; 1998-2016 Centro de Sensoriamento Remoto / Universidade
   Federal de Minas Gerais - Brazil.
   All Rights Reserved.

   \author Romulo Fernandes Machado
*/


#include "Config.h"
#define _DFF_CPP_LIBRARY_ BaseLib

#ifdef  _WINDOWS_
# include <windows.h>
#else
# include <fcntl.h>
# include <sys/file.h>
# include <unistd.h>
#endif

#include <chrono>
#include <string>
#include <thread>

#include "Exception.h"
#include "ExceptionUtils.h"
#include "FilenameLock.h"
#include "StringUtils.h"
#include "SystemUtils.h"


// N�mero m�ximo de tentativas de destravamento para evitar loops infinitos.
#define MAX_UNLOCK_ATTEMPTS 30

// N�mero de bytes para travar no arquivo.
#define LOCK_NUM_BYTES sizeof( int )


#ifdef _WINDOWS_


namespace DFF {


namespace {


/**
   \brief Retorna uma estrutura 'OVERLAPPED' para travar os primeiros 
   4 bytes do arquivo.
*/
OVERLAPPED getOverlapped() {
  OVERLAPPED overlapped;
  memset( &overlapped, 0, sizeof( OVERLAPPED ) );

  overlapped.Internal = LOCK_NUM_BYTES;
  return overlapped;
}


} // namespace '' 


FilenameLock::FilenameLock( const FILE_STRING& filename, 
  LockBehavior lockBehavior ) {

  m_handle = CreateFileW( filename.c_str(),
    GENERIC_READ | GENERIC_WRITE,
    FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
    NULL,
    OPEN_ALWAYS,
    FILE_ATTRIBUTE_NORMAL,
    NULL );

  if ( m_handle == INVALID_HANDLE_VALUE ) {
    std::string message;
    SystemUtils::getLastSystemError( message );

    throwException( DFF::Exception, "Failed to lock \"" << FROM_FS( filename ) << 
      "\", access failed. " << message );
  }

  const DWORD lockFlags = LOCKFILE_EXCLUSIVE_LOCK |
    ( lockBehavior == LB_THROW_ON_BUSY ? LOCKFILE_FAIL_IMMEDIATELY : 0 );

  OVERLAPPED overlapped = getOverlapped();
  BOOL lockSucceed = LockFileEx( m_handle, lockFlags, 0,
    LOCK_NUM_BYTES,
    0, &overlapped );

  if ( lockSucceed == FALSE ) {
    // Descarta o handle alocado.
    CloseHandle( m_handle );

    std::string message;
    SystemUtils::getLastSystemError( message );
    throwException( DFF::Exception, "Failed to lock \"" <<
      FROM_FS( filename ) << "\". " << message );
  }
}

FilenameLock::~FilenameLock() {

  if ( m_handle != INVALID_HANDLE_VALUE )
    release();
}


void FilenameLock::release() noexcept {

  OVERLAPPED overlapped = getOverlapped();
  for ( size_t numTries = 0; numTries < MAX_UNLOCK_ATTEMPTS; ++numTries ) {

    if ( UnlockFileEx( m_handle, 0, LOCK_NUM_BYTES, 0, &overlapped ) != 0 )
      break;

    std::this_thread::sleep_for( std::chrono::milliseconds( 250 ) );
  }

  CloseHandle( m_handle );
  m_handle = INVALID_HANDLE_VALUE;
}


} // namespace DFF


#else // _WINDOWS_


namespace DFF {


FilenameLock::FilenameLock( const FILE_STRING& filename, 
  LockBehavior lockBehavior ) 
  : m_handle( -1 ) {

  // O modo 0777 (octal, diferente de 777) deve ser usado para
  // evitar que o arquivo n�o possa ser acessado.
  m_handle = open( FROM_FS( filename ).c_str(), O_RDWR | O_CREAT, 0777 );

  if ( m_handle == -1 ) {
    std::string message;
    SystemUtils::getLastSystemError( message );

    throwException( DFF::Exception, "Failed to lock \"" << FROM_FS( filename ) << 
      "\", access failed. " << message );
  }

  int lockFD = flock( m_handle, LOCK_EX | 
    ( lockBehavior == LB_THROW_ON_BUSY ? LOCK_NB : 0 ) );

  if ( lockFD == -1 ) {
    std::string message;
    SystemUtils::getLastSystemError( message );

    throwException( DFF::Exception, "Failed to lock \"" << FROM_FS( filename ) << 
      "\". " << message );
  }
}

FilenameLock::~FilenameLock() {
  if ( m_handle != -1 )
    release();
}

void FilenameLock::release() noexcept {
  for ( size_t numTries = 0; numTries < MAX_UNLOCK_ATTEMPTS; ++numTries ) {

    int lockStatus = flock( m_handle, LOCK_UN );
    if ( lockStatus == 0 )
      break;

    std::this_thread::sleep_for( std::chrono::milliseconds( 250 ) );
  }

  close( m_handle );
  m_handle = -1;
}


} // namespace DFF


#endif // _WINDOWS_
