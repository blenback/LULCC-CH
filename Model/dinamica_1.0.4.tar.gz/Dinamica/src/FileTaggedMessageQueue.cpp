/**
   \file FileTaggedMessageQueue.cpp

   \brief Fila de mensagens (com tag) utilizando um arquivo para leitura 
   e escrita.

   Copyright&copy; 1998-2017 Centro de Sensoriamento Remoto / Universidade
   Federal de Minas Gerais - Brazil.
   All Rights Reserved.

   \author Romulo Fernandes Machado
*/


#include "Config.h"
#define _DFF_CPP_LIBRARY_ BaseLib

#include <chrono>
#include <cstdio>
#include <cstring>
#include <thread>

#include "Exception.h"
#include "ExceptionUtils.h"

#include "FileTaggedMessageQueue.h"
#include "FilenameLock.h"
#include "FilesystemUtils.h"
#include "Log.h"
#include "StringUtils.h"

#ifdef _DFF_ON_WINDOWS_
# define _WINDOWS_
#endif

#define BLOCK_SLEEP_INTERVAL_MS 100

#ifdef _DFF_ON_WINDOWS_
# define LOCK_SUFFIX L".lock"
#else
# define LOCK_SUFFIX ".lock"
#endif


namespace DFF {


namespace {


/**
   \brief Permite o uso de vari�veis opcionais.

   � necess�rio declarar o pr�prio optional aqui uma vez que o c�digo do R
   depende desse arquivo e boost::optional n�o pode ser usado.
*/
template < typename T >
class Optional {
public:
  Optional() : m_initialized( false ) {}

  T value() const { 
    if ( !m_initialized )
      throwException( DFF::Exception, "Value is not initialized." );

    return m_value;
  }
    
  Optional& operator=( const T& rhs ) {
    m_value = rhs;
    m_initialized = true;

    return *this;
  }

  explicit operator bool() const noexcept { 
    return m_initialized;
  }

private:

  T m_value;
  bool m_initialized;
};


inline void writeHeader( DFF::FileHandle& handle, 
  const DFF::FileTaggedMessageQueue::Header& header ) {

  handle.seek( 0 );
  handle.write( ( char* ) &header, sizeof( DFF::FileTaggedMessageQueue::Header ) );
  handle.flush();
}

template < typename T >
DFF::FileTaggedMessageQueue::Header getHeader( T& handle ) {
  DFF::FileTaggedMessageQueue::Header header;

  handle.seek( 0 );
  handle.read( ( char* ) &header, sizeof( DFF::FileTaggedMessageQueue::Header ) );

  return header;
}

inline void writeMessageHeader( DFF::FileHandle& handle, 
  const DFF::FileTaggedMessageQueue::MessageHeader& header ) {

  handle.write( ( char* ) &header, sizeof( DFF::FileTaggedMessageQueue::MessageHeader ) );
  handle.flush();
}

inline void writeMessage( DFF::FileHandle& handle, 
  const DFF::FileTaggedMessageQueue::MessageHeader& header, const void* data, 
  size_t dataLength ) {

  writeMessageHeader( handle, header );
  handle.write( static_cast< const char* >( data ), dataLength );
  handle.flush();
}

template < typename T >
DFF::FileTaggedMessageQueue::MessageHeader getMessageHeader( T& handle ) {
  DFF::FileTaggedMessageQueue::MessageHeader header;

  handle.read( ( char* ) &header, sizeof( DFF::FileTaggedMessageQueue::MessageHeader ) );
  return header;
}


} // namespace ''


FileTaggedMessageQueue::FileTaggedMessageQueue( const FILE_STRING& filename, 
  size_t messageSize, size_t messageCount ) 
  : m_filename( filename ),
    m_messageSize( messageSize ),
    m_maximumMessageCount( messageCount ) { 

  // Obt�m a trava exclusiva para cria��o do arquivo (como sup�e-se que 
  // o arquivo n�o existe, dispara se a trava existir).
  const FILE_STRING lockFilename( m_filename + LOCK_SUFFIX );
  const FilenameLock lock( lockFilename, FilenameLock::LB_THROW_ON_BUSY );

  // Verifica se a sess�o j� existe.
  if ( FileHandle( m_filename, TO_FS( "r" ) ).is_open() )
    throwException( DFF::Exception, "Failed to create tagged message "
      "queue \"" << FROM_FS( m_filename ) << "\". Session already exist." );

  // Cria o arquivo em modo bin�rio.
  FileHandle handle( m_filename, TO_FS( "wb" ) );
  if ( handle.is_open() == false )
    throwException( DFF::Exception, "Failed to create tagged message "
      "queue \"" << FROM_FS( m_filename ) << "\"." );

  // Escreve o cabe�alho com as informa��es 
  const FileTaggedMessageQueue::Header header = { messageSize, messageCount };
  writeHeader( handle, header );

  // Escreve no arquivo bytes suficientes para acomodar todas as mensagens.
  const FileTaggedMessageQueue::MessageHeader msgHeader = {};

  char* tmpData = new char[ messageSize ];
  memset( tmpData, 0, messageSize );

  for ( size_t i = 0; i < messageCount; ++i ) {
    writeMessage( handle, msgHeader, tmpData, messageSize );
  }

  delete [] tmpData;
}

FileTaggedMessageQueue::FileTaggedMessageQueue( const FILE_STRING& filename ) 
  : m_filename( filename ) {

  // Obt�m a trava exclusiva para leitura do arquivo.
  const FILE_STRING lockFilename( m_filename + LOCK_SUFFIX );
  const FilenameLock lock( lockFilename );

  FileHandle handle( m_filename, TO_FS( "r+b" ) );
  if ( handle.is_open() == false )
    throwException( DFF::Exception, "Failed to open tagged message "
      "queue \"" << FROM_FS( m_filename ) << "\"." );

  // Recupera o cabe�alho para preencher o tamanho da mensagem armazenada.
  const FileTaggedMessageQueue::Header header( getHeader( handle ) );
  m_messageSize = header.blockSize;
  m_maximumMessageCount = header.blockCount;
}

void FileTaggedMessageQueue::write( const std::string& tag, const void* data, 
  size_t size, Cancellable* cancellable ) {

  while ( true ) {
    const FILE_STRING lockFilename( m_filename + LOCK_SUFFIX );
    FilenameLock lock( lockFilename );

    FileHandle handle( m_filename, TO_FS( "r+b" ) );
    if ( handle.is_open() == false )
      throwException( DFF::Exception, "Failed to open tagged message "
        "queue \"" << FROM_FS( m_filename ) << "\"." );

    const FileTaggedMessageQueue::Header header( getHeader( handle ) );
    const size_t messagesStartIndex = handle.tellg();

    // Procura o �ndice da mensagem com o tag especificado ou o primeiro 
    // slot dispon�vel, caso a tag n�o apare�a em nenhuma mensagem.
    Optional< size_t > messageSlot;
    for ( size_t i = 0; i < m_maximumMessageCount; ++i ) {
      handle.seek( messagesStartIndex + i * ( m_messageSize + 
        sizeof ( FileTaggedMessageQueue::MessageHeader ) ) );

      const FileTaggedMessageQueue::MessageHeader msgHeader( 
        getMessageHeader( handle ) );

      // Uma vez que a tag � encontrada, a busca pode ser encerrada.
      if ( msgHeader.inUse && msgHeader.hasTag( tag ) ) {
        messageSlot = i;
        break;
      } 

      // Verifica se o slot est� dispon�vel, caso a tag n�o seja encontrada.
      if ( !msgHeader.inUse && !messageSlot ) {
        messageSlot = i;
      }
    }

    // Foi encontrado um slot para grava��o da mensagem ou uma
    // mensagem com a mesma tag existente.
    if ( messageSlot ) {
      handle.seek( messagesStartIndex + messageSlot.value() * ( m_messageSize +
        sizeof ( FileTaggedMessageQueue::MessageHeader ) ) );

      writeMessage( handle, { true, tag }, data, size );
      break;
    }

    // Libera o lock e espera um timeout para uma nova tentativa.
    lock.release();
    std::this_thread::sleep_for( std::chrono::milliseconds( BLOCK_SLEEP_INTERVAL_MS ) );

    if ( cancellable != nullptr && cancellable->isCancelled() )
      throwException( DFF::Exception, "Execution aborted." );

  } // while ( true )
}


void FileTaggedMessageQueue::read( const std::string& tag, void* data, 
  size_t size, Cancellable* cancellable ) {
  while ( true ) {
    const FILE_STRING lockFilename( m_filename + LOCK_SUFFIX );
    FilenameLock lock( lockFilename );

    FileHandle handle( m_filename, TO_FS( "r+b" ) );
    if ( handle.is_open() == false )
      throwException( DFF::Exception, "Failed to open tagged message "
        "queue \"" << FROM_FS( m_filename ) << "\"." );

    const FileTaggedMessageQueue::Header header( getHeader( handle ) );
    const size_t messagesStartIndex = handle.tellg();
    for ( size_t i = 0; i < m_maximumMessageCount; ++i ) {
      handle.seek( messagesStartIndex + i * ( m_messageSize + 
        sizeof ( FileTaggedMessageQueue::MessageHeader ) ) );

      const FileTaggedMessageQueue::MessageHeader msgHeader( 
        getMessageHeader( handle ) );

      if ( msgHeader.inUse && msgHeader.hasTag( tag ) ) {
        handle.read( ( char* ) data, size );
      
        // Ap�s ser lida, a mensagem deve ser marcada no arquivo.
        handle.seek( messagesStartIndex + i * ( m_messageSize + 
          sizeof( FileTaggedMessageQueue::MessageHeader ) ) );

        writeMessageHeader( handle, { false, "\0" } );
        return;
      }
    }

    // Libera o lock e espera um timeout para uma nova tentativa.
    lock.release();
    std::this_thread::sleep_for( std::chrono::milliseconds( BLOCK_SLEEP_INTERVAL_MS ) );

    if ( cancellable != nullptr && cancellable->isCancelled() )
      throwException( DFF::Exception, "Execution aborted." );

  } // while ( true )
}

void FileTaggedMessageQueue::destroy( const FILE_STRING& filename ) {

  logDebug( "Destroying tagged file message queue \"" << FROM_FS( filename + LOCK_SUFFIX ) << "\"" );
  FilesystemUtils::deleteFile( filename + LOCK_SUFFIX );

  logDebug( "Destroying tagged file message queue \"" << FROM_FS( filename ) << "\"" );
  FilesystemUtils::deleteFile( filename );
}


} // namespace DFF

