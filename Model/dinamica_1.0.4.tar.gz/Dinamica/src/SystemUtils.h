#ifndef _DFF_SYSTEM_UTILS_H_
#define _DFF_SYSTEM_UTILS_H_


#include "Config.h"

#include <string>
#ifdef _DFF_ON_WINDOWS_
# include <windows.h>
#endif


namespace DFF {


class DFF_PUBLIC SystemUtils {
public:
  static bool getLastSystemError( std::string& message );

  static std::string getEnvironmentVariableValue( const std::string& variableName );
};


} /* DFF */


#endif
