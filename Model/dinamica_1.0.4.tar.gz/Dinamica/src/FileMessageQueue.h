/**
   \file FileMessageQueue.h

   \brief Fila de mensagens utilizando um arquivo para leitura e escrita.

   Copyright&copy; 1998-2016 Centro de Sensoriamento Remoto / Universidade
   Federal de Minas Gerais - Brazil.
   All Rights Reserved.

   \author Romulo Fernandes Machado
*/


#ifndef _DFF_FILE_MESSAGE_QUEUE_H_
#define _DFF_FILE_MESSAGE_QUEUE_H_


#include "Config.h"
#include "Cancellable.h"

#include <string>

#ifdef _DINAMICA_EGO_
# undef _DFF_H_LIBRARY_
# define _DFF_H_LIBRARY_ BaseLib
# include "Library.h"
#endif

#ifdef _DFF_ON_WINDOWS_
# define _WINDOWS_
#endif


namespace DFF {


class DFF_PUBLIC FileMessageQueue {
public:

  /**
     \brief Cabe�alho do arquivo contendo as mensagens.
  */
  struct Header {
    /**
       \brief Posi��o do cabe�ote de leitura.
    */
    uint64_t readPtr;

    /**
       \brief Posi��o do cabe�ote de escrita.
    */
    uint64_t writePtr;

    /**
       \brief Tamanho do bloco de mensagem.
    */
    uint64_t blockSize;

    /**
       \brief Quantidade de blocos alocados.
    */
    uint64_t blockCount;
  };

  /**
     \brief Cria um novo arquivo contendo uma fila de mensagens.

     \param filename Nome do arquivo contendo as mensagens.

     \param messageSize Tamanho em bytes das mensagens a serem gravadas.

     \param messageCount N�mero m�ximo de mensagens a serem gravadas no arquivo.
  */
  FileMessageQueue( const FILE_STRING& filename, size_t messageSize, 
    size_t messageCount );

  /**
     \brief Abre um arquivo contendo uma fila de mensagens.

     \param filename Nome do arquivo contendo as mensagens.

     \param accessType O arquivo ser� criado para escrita. O �nico valor aceito
     para esse parametro � AccessType::OPEN.
  */
  FileMessageQueue( const FILE_STRING& filename );

  /**
     \brief Escreve uma mensagem na fila. Bloqueia se a fila estiver cheia.

     \param data Ponteiro para o buffer de dados a ser escrito.

     \param size N�mero de bytes a serem escritos.

     \param cancellable Ponteiro para cancellable para verifica��o de 
     interrup��es (opcional).
  */
  void write( const void* data, size_t size, Cancellable* cancellable = nullptr );

  /**
     \brief L� uma mensagem da fila. Bloqueia se a fila estiver vazia.

     \param data Ponteiro para o buffer de dados onde as informa��es lidas 
     ser�o gravadas.

     \param size N�mero de bytes a serem lidos.

     \param cancellable Ponteiro para cancellable para verifica��o de 
     interrup��es (opcional).
  */
  void read( void* data, size_t size, Cancellable* cancellable = nullptr );

  /**
     \brief Destr�i os arquivos utilizados por uma fila.

     \param filename Nome de arquivo utilizado para cria��o da fila.
  */
  static void destroy( const FILE_STRING& filename );

  /**
     \brief Retorna o n�mero m�ximo de mensagens que podem ser gravadas 
     no arquivo.
  */
  inline const size_t getMaximumMessageCount() const {
    return m_maximumMessageCount;
  }

private:

  /**
     \brief Nome do arquivo onde a fila de mensagem est� salva.
  */
  FILE_STRING m_filename;

  /**
     \brief Tamanho (em bytes) de cada mensagem armazenada na fila.
  */
  size_t m_messageSize;

  /**
     \brief Armazena o n�mero m�ximo de mensagens que podem ser armazenadas.
  */
  size_t m_maximumMessageCount;

}; /* FileMessageQueue */


} /* DFF */


#endif /* _DFF_FILE_MESSAGE_QUEUE_H_ */
