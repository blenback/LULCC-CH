#ifndef _BASE_CONFIG_H_
#define _BASE_CONFIG_H_

#include <cstddef>

#if defined(__linux) || defined(__linux__) || defined(__gnu_linux__) || defined(linux)
# define _DFF_ON_LINUX_
#elif defined(__APPLE__)
# define _DFF_ON_MAC_
#else
# define _DFF_ON_WINDOWS_
# define _WINDOWS_
#endif

#ifdef _DFF_ON_WINDOWS_
# define _DFF_LITTLE_ENDIAN_
# define WIN32_LEAN_AND_MEAN
# include <new.h>
# ifdef NOMINMAX
#  undef NOMINMAX
# endif
# define NOMINMAX
# include <windef.h>
# include <winnt.h>
# include <windows.h>
# include <minwinbase.h>
# include <winbase.h>
# include <fileapi.h>
# include <handleapi.h>
# include <shellapi.h>
# include <winuser.h>
# include <winreg.h>
# include <winnetwk.h>
#else
# define _DFF_LITTLE_ENDIAN_
#endif

#define DFF_PUBLIC 

#ifdef _DFF_ON_WINDOWS_
# define FILE_STRING std::wstring
# define FILE_CHAR wchar_t
# define TO_FS(X) DFF::StringUtils::fromUTF8(X)
# define FROM_FS(X) DFF::StringUtils::toUTF8(X)
#else
# define FILE_STRING std::string
# define FILE_CHAR char
# define TO_FS(X) (X)
# define FROM_FS(X) (X)
#endif

#include <cassert>
#include <sstream>
#include "Exception.h"

#define __TOKENPASTE(x, y) x ## y
#define __TOKENPASTE2(x, y) __TOKENPASTE(x, y)

#define STRINGIZE2(EXPR) #EXPR
#define STRINGIZE(EXPR) STRINGIZE2(EXPR)
#define BOOST_ASSERT(EXPR) \
  do{\
    if ( ! ( EXPR ) ) {\
    std::stringstream __str; \
    __str << "Assertion failed at (" << __FILE__ << ":" <<\
    __LINE__ << "). '" << STRINGIZE(EXPR) << "' is false." << std::endl;\
    throw DFF::Exception(__str.str());\
    }\
  } while( false )


#endif /* _BASE_CONFIG_H_ */
