#ifndef _DFF_EXCEPTION_UTILS_H_
#define _DFF_EXCEPTION_UTILS_H_

#include "Config.h"
#include <sstream>


namespace DFF {


# define throwException_( EXCEPTION, MESSAGE ) \
do { \
  std::stringstream exceptionStream__; \
  exceptionStream__ << MESSAGE; \
  \
  EXCEPTION exception__( exceptionStream__.str() ); \
  \
  throw exception__; \
  \
} while( false )

#ifdef _DFF_LOG_DEBUG_
# define throwException( EXCEPTION, MESSAGE ) \
do { \
  std::stringstream exceptionStream__; \
  exceptionStream__ << MESSAGE; \
  \
  EXCEPTION exception__( exceptionStream__.str() ); \
  \
  logDebug( exception__.getName() << ": " << exceptionStream__.str() ); \
  \
  throw exception__; \
  \
} while( false )

#else
# define throwException( EXCEPTION, MESSAGE ) \
throwException_( EXCEPTION, MESSAGE )
#endif

} /* DFF */


#endif /* _DFF_EXCEPTION_UTILS_H_ */
