#ifndef _DFF_FILESYSTEM_UTILS_H_
#define _DFF_FILESYSTEM_UTILS_H_

#include "Config.h"
#include "StringUtils.h"

#include <string>


namespace DFF {


class FileHandle {
public:
  FileHandle( const FILE_STRING& filename, 
    const FILE_STRING& mode );

  ~FileHandle();

  inline bool is_open() const { return m_isOpen; }
  inline const FILE_STRING& filename() const { return m_filename; }

  long tellg() const;
  void seek( long pos );
  void read( char* result, size_t numBytes );
  void write( const char* data, size_t numBytes );

  void close( bool noExcept = false );
  void flush();

  friend std::ostream& operator << ( std::ostream& lhs, const FileHandle& rhs ) {
    lhs << FROM_FS( rhs.filename() );
    return lhs;
  }

private:
  FILE* m_handle;
  bool m_isOpen;
  FILE_STRING m_filename;
};


class DFF_PUBLIC FilesystemUtils {
public:
  static std::string getCompleteTemporaryPath( const std::string& baseName );
  static std::string getTemporaryFilename( const std::string& extension = "" );
  static void deleteFile( const FILE_STRING& filename );
}; /* FilesystemUtils */


} /* DFF */

  
#endif /* _DFF_FILESYSTEM_UTILS_H_ */
