/**
   \file ExternalCommunication.cpp

   \brief Utilit�rio para comunica��o com aplica��es externas.

   Copyright&copy; 1998-2017 Centro de Sensoriamento Remoto / Universidade
   Federal de Minas Gerais - Brazil.
   All Rights Reserved.

   \author Romulo Fernandes Machado
*/


#include "Config.h"
#define _DFF_CPP_LIBRARY_ BaseLib

#include <cstdlib>
#include <exception>
#include <sstream>

#include "Exception.h"
#include "ExceptionUtils.h"
#include "ExternalCommunication.h"
#include "FilesystemUtils.h"
#include "Log.h"
#include "StringUtils.h"


namespace DFF {


namespace {


/**
   \brief Retorna o caminho completo para o arquivo da sess�o com tags.
   O caminho retornado � o caminho do diret�rio tempor�rio acrescido
   do nome de base passado pelo usu�rio e o sufixo '.tagQueue'.

   \param baseName Nome de base a ser usado para sess�o.
*/
std::string getTaggedSessionName( const std::string& baseName ) {
  return DFF::FilesystemUtils::getCompleteTemporaryPath( baseName + ".tagQueue" );
}

/**
   \brief Retorna o caminho completo para o arquivo da sess�o.
   O caminho retornado � o caminho do diret�rio tempor�rio acrescido
   do nome de base passado pelo usu�rio e o sufixo '.queue'.

   \param baseName Nome de base a ser usado para sess�o.
*/
std::string getSessionName( const std::string& baseName ) {
  return DFF::FilesystemUtils::getCompleteTemporaryPath( baseName + ".queue" );
}

/**
   \brief Retorna se o nome de arquivo passado existe. A fun��o do
   FilesystemUtils n�o � utilizada pois ela depende de boost::filesystem::path
   e essa vers�o � port�vel.
*/
bool filenameExists( const FILE_STRING& filename ) {
  FileHandle handle( filename, TO_FS( "r" ) );
  return handle.is_open();
}


} // namespace ''


ExternalCommunication::ExternalCommunication() 
  : m_sessionCreated( false ) {
}

ExternalCommunication::~ExternalCommunication() {
}

void ExternalCommunication::createSession( const std::string& sessionIdentifier ) {
  if ( m_sessionCreated )
    throwException( DFF::Exception, "A session named \"" << m_sessionIdentifier <<
      "\" already exists." );

  BOOST_ASSERT( m_sessionIdentifier.empty() );
  BOOST_ASSERT( m_sendQueue == nullptr );
  BOOST_ASSERT( m_receiveQueue == nullptr );
  BOOST_ASSERT( m_tagSendQueue == nullptr );
  BOOST_ASSERT( m_tagReceiveQueue == nullptr );

  const std::string receiveQueueName( getSessionName( 
    sessionIdentifier + SHARED_QUEUE_SERVER_SUFFIX ) );

  m_receiveQueue = std::make_shared< FileMessageQueue >( TO_FS( receiveQueueName ),
    sizeof( Message ), QUEUE_MAX_MESSAGES );

  const std::string receiveTagQueueName( getTaggedSessionName( 
    sessionIdentifier + SHARED_QUEUE_SERVER_SUFFIX ) );

  m_tagReceiveQueue = std::make_shared< FileTaggedMessageQueue >( TO_FS( receiveTagQueueName ),
    sizeof( Message ), QUEUE_MAX_MESSAGES );

  logDebug( "External communication receive queue created on \"" << 
    receiveQueueName << "\"." );
  
  const std::string sendQueueName( getSessionName( 
    sessionIdentifier + SHARED_QUEUE_CLIENT_SUFFIX ) );

  m_sendQueue = std::make_shared< FileMessageQueue >( TO_FS( sendQueueName ),
    sizeof( Message ), QUEUE_MAX_MESSAGES );

  const std::string sendTagQueueName( getTaggedSessionName( 
    sessionIdentifier + SHARED_QUEUE_CLIENT_SUFFIX ) );

  m_tagSendQueue = std::make_shared< FileTaggedMessageQueue >( TO_FS( sendTagQueueName ),
    sizeof( Message ), QUEUE_MAX_MESSAGES );

  logDebug( "External communication send queue created on \"" << 
    sendQueueName << "\"." );

  m_sessionCreated = true;
  m_sessionIdentifier = sessionIdentifier;
  logDebug( "External communication session \"" << sessionIdentifier << "\" created." );
}

void ExternalCommunication::destroy() {

  // Apenas apaga os objetos se a inst�ncia tiver sido respons�vel
  // pela cria��o das sess�es.
  if ( m_sessionCreated ) {

    logDebug( "Cleaning up External Communication session \"" <<
      m_sessionIdentifier << "\"" );

    m_receiveQueue.reset();
    m_sendQueue.reset();
    m_tagReceiveQueue.reset();
    m_tagSendQueue.reset();
    destroySession( m_sessionIdentifier );

    m_sessionIdentifier.clear();
    m_sessionCreated = false;
  }
}

void ExternalCommunication::openSession( const std::string& sessionIdentifier ) {
  if ( m_sessionCreated )
    throwException( DFF::Exception, "A session named \"" << m_sessionIdentifier <<
      "\" already exists." );

  BOOST_ASSERT( m_sessionIdentifier.empty() );
  BOOST_ASSERT( m_receiveQueue == nullptr );
  BOOST_ASSERT( m_sendQueue == nullptr );
  BOOST_ASSERT( m_tagReceiveQueue == nullptr );
  BOOST_ASSERT( m_tagSendQueue == nullptr );

  try {
    m_sessionIdentifier = sessionIdentifier;
    m_receiveQueue = std::make_shared< FileMessageQueue >( 
      TO_FS( getSessionName( m_sessionIdentifier + SHARED_QUEUE_CLIENT_SUFFIX ) ) );

    m_tagReceiveQueue = std::make_shared< FileTaggedMessageQueue >(
      TO_FS( getTaggedSessionName( m_sessionIdentifier + SHARED_QUEUE_CLIENT_SUFFIX ) ) );

    m_sendQueue = std::make_shared< FileMessageQueue >(
      TO_FS( getSessionName( m_sessionIdentifier + SHARED_QUEUE_SERVER_SUFFIX ) ) );

    m_tagSendQueue = std::make_shared< FileTaggedMessageQueue >(
      TO_FS( getTaggedSessionName( m_sessionIdentifier + SHARED_QUEUE_SERVER_SUFFIX ) ) );

  } catch ( std::exception& ex ) {

    m_sessionIdentifier.clear();
    m_receiveQueue.reset();
    m_sendQueue.reset();
    m_tagReceiveQueue.reset();
    m_tagSendQueue.reset();

    throwException( DFF::Exception, "Failed to open session \"" << 
      sessionIdentifier << "\", reason: " << ex.what() );
  }
}

void ExternalCommunication::sendMessage( const Message& message, 
  const std::string& tag, Cancellable* cancellable ) {

  if ( m_sendQueue == nullptr
    || m_tagSendQueue == nullptr
    || m_tagReceiveQueue == nullptr
    || m_receiveQueue == nullptr ) {

    throwException( DFF::Exception, "Failed to send message, session is closed." );
  }

  try {
    if ( tag.empty() )
      m_sendQueue->write( &message, sizeof( Message ), cancellable );
    else
      m_tagSendQueue->write( tag, &message, sizeof( Message ), cancellable );
  } catch ( std::exception& ex ) {
    throwException( DFF::Exception, "Failed to send external message (identifier: " <<
      message.m_identifier << ", number: " << message.m_number <<
      ", handle: " << message.getString() << "). Reason: " <<
      ex.what() << "." );
  }
}

DFF::ExternalCommunication::Message ExternalCommunication::receiveMessage( 
  const std::string& tag, Cancellable* cancellable ) {

  if ( m_sendQueue == nullptr
    || m_tagSendQueue == nullptr
    || m_tagReceiveQueue == nullptr
    || m_receiveQueue == nullptr ) {

    throwException( DFF::Exception, "Failed to send message, session is closed." );
  }

  Message receivedMessage;
  try {
    if ( tag.empty() )
      m_receiveQueue->read( &receivedMessage, sizeof( Message ), cancellable );
    else
      m_tagReceiveQueue->read( tag, &receivedMessage, sizeof( Message ), cancellable );

    return receivedMessage;

  } catch ( std::exception& ex ) {
    throwException( DFF::Exception, "Failed to receive external message: " << 
      ex.what() );
  }
}

void ExternalCommunication::destroySession( const std::string& identifier ) {

  DFF::FileMessageQueue::destroy( TO_FS( getSessionName( identifier + 
    SHARED_QUEUE_CLIENT_SUFFIX ) ) );

  DFF::FileTaggedMessageQueue::destroy( TO_FS( getTaggedSessionName( identifier + 
    SHARED_QUEUE_CLIENT_SUFFIX ) ) );

  DFF::FileMessageQueue::destroy( TO_FS( getSessionName( identifier + 
    SHARED_QUEUE_SERVER_SUFFIX ) ) );

  DFF::FileTaggedMessageQueue::destroy( TO_FS( getTaggedSessionName( identifier + 
    SHARED_QUEUE_SERVER_SUFFIX ) ) );
}

bool ExternalCommunication::sessionExists( const std::string& identifier ) {
  const std::string clientIdentifier( getSessionName( identifier + 
    SHARED_QUEUE_CLIENT_SUFFIX ) );
  const std::string serverIdentifier( getSessionName( identifier + 
    SHARED_QUEUE_SERVER_SUFFIX ) );

  const std::string clientTagIdentifier( getTaggedSessionName( identifier + 
    SHARED_QUEUE_CLIENT_SUFFIX ) );
  const std::string serverTagIdentifier( getTaggedSessionName( identifier + 
    SHARED_QUEUE_SERVER_SUFFIX ) );

  return filenameExists( TO_FS( clientIdentifier ) ) 
    || filenameExists( TO_FS( serverIdentifier ) ) 
    || filenameExists( TO_FS( clientTagIdentifier ) ) 
    || filenameExists( TO_FS( serverTagIdentifier ) );
}

size_t ExternalCommunication::getMaxNumberOfMessages() const {
  if ( m_sendQueue == nullptr
    || m_tagSendQueue == nullptr
    || m_tagReceiveQueue == nullptr
    || m_receiveQueue == nullptr ) {

    throwException( DFF::Exception, "Failed to return maximum number of "
      "unqueued messages, session is closed." );
  }

  return m_sendQueue->getMaximumMessageCount();
}

void ExternalCommunication::storeNumbersOnFilename ( size_t numberCount,
  const std::function< double ( size_t ) >& getNumber, 
  const std::string& filename ) {

#ifdef _DFF_ON_WINDOWS_
  DFF::FileHandle handle( TO_FS( filename ), L"wb" );
#else
  DFF::FileHandle handle( TO_FS( filename ), "wb" );
#endif

  if ( handle.is_open() == false )
    throwException( DFF::Exception, "Failed to create temporary file \"" <<
      filename << "\" to store number vector." );

  if ( numberCount > std::numeric_limits< int >::max() )
    throwException( DFF::Exception, "List is too big to be communicated. " <<
      "Actual size " << numberCount << ", maximum size " << 
      std::numeric_limits< int >::max() );

  const int listCount = static_cast< int >( numberCount );
  handle.write( ( char* ) &listCount, sizeof( int ) );

  for ( size_t i = 0; i < numberCount; ++i ) {
    const double number = getNumber( i );
    handle.write( ( char* ) &number, sizeof( double ) );
  }

  handle.close();
}

void ExternalCommunication::getNumbersFromFilename( 
  const std::function< void( double ) >& setNumber, 
  const std::string& filename ) {

#ifdef _DFF_ON_WINDOWS_
  DFF::FileHandle handle( TO_FS( filename ), L"rb" );
#else
  DFF::FileHandle handle( TO_FS( filename ), "rb" );
#endif

  if ( handle.is_open() == false )
    throwException( DFF::Exception, "Failed to read temporary file \"" <<
      filename << "\" of stored number vector." );

  int numCount = 0;
  handle.read( ( char* ) &numCount, sizeof( int ) );

  for ( int i = 0; i < numCount; ++i ) {
    double inDouble = 0;
    handle.read( ( char* ) &inDouble, sizeof( double ) );
    setNumber( inDouble );
  }
}

// Evita que bibliotecas externas incluam arquivos do Dinamica.
#ifdef _DINAMICA_EGO_

ExternalCommunication& ExternalCommunicationManager::Instance() {
  return SingletonHolder< ExternalCommunication >::Instance();
}

#endif // _DINAMICA_EGO_

std::ostream& operator<<( std::ostream& os, ExternalMessageTypes type ) {
  switch ( type ) {
  case EMT_NUMBER:
    os << "Number";
    break;
  case EMT_NUMBER_LIST:
    os << "Number List";
    break;
  case EMT_LOOKUP_TABLE:
    os << "Lookup Table";
    break;
  case EMT_STRING:
    os << "String";
    break;
  case EMT_ERROR_DESCRIPTION:
    os << "Error Description";
    break;
  default:
    // O cast � necess�rio para evitar recurs�o.
    os << "Unknown (" << static_cast< int >( type ) << ")";
    break;
  }

  return os;
}


} // namespace DFF
